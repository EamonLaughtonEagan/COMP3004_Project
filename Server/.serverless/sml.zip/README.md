##README
This is the middleware of our application. It is server-side code for receiving HTTP requests from clients. Requests are mapped to database queries, and the results are returned to the client.

The root URI of the api is https://bsdbwvwyf7.execute-api.us-east-2.amazonaws.com/dev/

API calls are made through standard HTTP get/post/put/delete requests to this URI. Some examples of how to use the API are listed below.

<details>
  <summary>Query a complete list of jobs</summary>
    
    Method:     GET
    Resource:   jobs/
    Params:     None

    Ex: curl -X GET https://bsdbwvwyf7.execute-api.us-east-2.amazonaws.com/dev/jobs/

    Response:
    {
    
    }


</details>
<details>
  <summary>Query a specific job by id</summary>

    Method:     GET
    Resource:   jobs/{id}
    Params:     None

    Ex: curl -X GET https://bsdbwvwyf7.execute-api.us-east-2.amazonaws.com/dev/jobs/2
</details>

<details>
    <summary>Create a new job</summary>

    Method:     POST 
    Resource:   jobs/
    Params:     
        - 


</details>

<details>
    <summary>summary</summary>


</details>


Update an existing job:

    PUT
    https://bsdbwvwyf7.execute-api.us-east-2.amazonaws.com/dev/jobs/

# A collapsible section with markdown
